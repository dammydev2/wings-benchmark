


Dear {{ $client_name }}, 
<p>Please find attached detailing deliveries for the period indicated in the below table.<br> This is for your review and processing.</p>

<P>Find our bank details below:</p>
	<P>Account Name: <b>NINESEAS LIMITED</b></p>
		<P>Bank: <b>Guaranty Trust Bank</b></p>
			<P>Account No: <b>0052839534</b></p>
				<p>Thanks for your patronage</p>
				<p>Best Regards from Olufemi</p>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				