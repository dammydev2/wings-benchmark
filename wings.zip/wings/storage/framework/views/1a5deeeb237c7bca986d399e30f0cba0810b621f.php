<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<?php if(Session::has('success')): ?>
    	<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    	<?php endif; ?>

    	<?php if(Session::has('error')): ?>
    	<div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
    	<?php endif; ?>

        <div class="col-sm-12 col-lg-8">
           <table class="table table-bordered" >
              <tr>
                 <th colspan="4"><center><h3>Consigned to me </h3></center></th>
             </tr>
             <tr>
                 <th>Type</th>
                 <th>Item</th>
                 <th>Order ID</th>
                 <th></th>
             </tr>

             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
                <td><?php echo e($row->type); ?></td>
                <td><?php echo e($row->item); ?></td>
                <td><?php echo e($row->order_id); ?></td>
                <td><a href="<?php echo e(url('/delivered/'.$row->id)); ?>" onclick="return confirm('Are you sure?')">Delivered</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </table>
    </div>


</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/despatch/consign.blade.php ENDPATH**/ ?>