<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-8 col-sm-12 panel panel-primary">
			<div class="panel-heading">Add a new Order</div>
			<div class="panel-body">

				<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>

				<form method="post" action="<?php echo e(url('/neworder')); ?>">
					<?php echo csrf_field(); ?>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Customer Type</label>
						<select class="form-control" name="type">
							<option>Walk in</option>
							<option>Contract Clients</option>
							<option>Coporate</option>
						</select>
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Item</label>
						<input type="text" name="item" class="form-control">
					</div>

					<div class="form-group col-lg-12 col-sm-12">
						<label>Pick-up Address</label>
						<input type="text" name="address" class="form-control">
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Delivery Type</label>
						<select class="form-control" name="delivery_type">
							<option>Inter State</option>
							<option>Within State</option>
						</select>
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Delivery Amount</label>
						<input type="text" name="amount" class="form-control">
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Customer Name</label>
						<input type="text" name="name" class="form-control">
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Customer phone</label>
						<input type="text" name="cus_phone" class="form-control">
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Customer Email</label>
						<input type="email" name="email" class="form-control">
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Delivery Beneficiary Name</label>
						<input type="text" name="ben_name" class="form-control">
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Beneficiary Phone</label>
						<input type="text" name="ben_phone" class="form-control">
					</div>

					<div class="form-group col-lg-6 col-sm-12">
						<label>Delivery Address</label>
						<input type="text" name="pick_address" class="form-control">
					</div>

					<input type="submit" class="btn btn-primary" name="">

				</form>

			</div>  
		</div>



	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/despatch/addorder.blade.php ENDPATH**/ ?>