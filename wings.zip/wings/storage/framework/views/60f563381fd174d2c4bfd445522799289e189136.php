<div class="col-lg-12 col-sm-12">
					<table class="table">

						<tr>
							<th colspan="13">

								<h3 style="margin-top: -40px; margin-left:150px;">WINGS BY NINESEAS LOGISTICS</h3>
								<span><center> Suite 17, Block B, Alausa Shopping Complex, 131 Obafemi Awolowo, Ikeja, Lagos State. </center></span>
								<span><center><i class="fa fa-phone"></i> 0908-6532-777 ,  08097765985 <i class="fa fa-envelope"></i> info@wingsng.com </center></span>
							</th>
						</tr>
						<tr>
							<th colspan="13"><center><?php echo e($client_name); ?> (<?php echo e($phone); ?>) delivery data from <?php echo e(Session::get('from')); ?> to <?php echo e(Session::get('to')); ?></center></th>
						</tr>
						<tr>
							<th>Date</th>
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                             <?php if($row->type == 'special order'): ?>
                             <th>Item</th>
                             <?php endif; ?>
							<th>Name of client</th>
							<th>Pick up Point</th>
							<th>Delivery Point</th>
							<th>Pickup Time</th>
							<th>Delivery Time</th>
							<th>Payment Status</th>
							<th>Order ID</th>
							<th>Beneficiary Name</th>
							<th>Beneficiary Address</th>
							<th>Beneficiary Phone</th>
							<th>Amount</th>
						</tr>
						<?php $sum=0; ?>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th> <?php echo e($row->created_at); ?> </th>
							 <?php if($row->type == 'special order'): ?>
                             <th><?php echo e($row->item); ?></th>
                             <?php endif; ?>
							<th> <?php echo e($row->name); ?> </th>
							<th> <?php echo e($row->address); ?> </th>
							<th> <?php echo e($row->pick_address); ?> </th>
							<th> <?php echo e($row->pick_time); ?> </th>
							<th> <?php echo e($row->delivery_time); ?> </th>
							<th> <?php echo e($row->status); ?> </th>
							<th> <?php echo e($row->order_id); ?> </th>
							<th> <?php echo e($row->ben_name); ?> </th>
							<th> <?php echo e($row->pick_address); ?> </th>
							<th> <?php echo e($row->ben_phone); ?> </th>
							<th> <?php echo e($row->amount); ?> </th>
							<?php $sum += (int)$row->amount ?>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th colspan="12" class="text-right">Cost of Delivery</th>
							<th> <?php echo e(number_format($sum, 2)); ?> </th>
						</tr>
						<tr style="color: green;">
							<th colspan="12" class="text-right">Paid</th>
							<th>
								<?php $sum2=0; ?> 
								<?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $sum2 += (int)$row2->amount ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php echo e(number_format($sum2, 2)); ?>

							</th>
						</tr>
						<tr style="color: red;">
							<th colspan="12" class="text-right">Balance</th>
							<th><?php echo e($sum - $sum2); ?></th>
						</tr>
					</table>
				</div>


			<!--	<h1>Mail body goes  here</h1>
				<p><?php echo e($subject); ?></p> -->

				<style type="text/css">
					th{
						border: 1px solid #000;
					}
					.text-right{
						text-align: right;
					}
					table{
					    font-size: 9px;
					}
				</style>

				<!-- Latest compiled and minified CSS -->
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

				<!-- jQuery library -->
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

				<!-- Latest compiled JavaScript -->
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script><?php /**PATH /home/wingsben/wings/resources/views/mails/mailpdf.blade.php ENDPATH**/ ?>