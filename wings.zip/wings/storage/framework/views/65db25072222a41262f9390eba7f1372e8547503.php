<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

<div class="col-lg-10 col-sm-12">
    	<table class="table">
    		<tr>
    			<th>Date</th>
    			<th>Name of client</th>
    			<th>Pick up Point</th>
    			<th>Delivery Point</th>
    			<th>Amount</th>
                <th>Status</th>
                <th>Desatch by</th>
                <th>Order ID</th>
    		</tr>
    		<?php $sum=0; ?>
    		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<th> <?php echo e($row->created_at); ?> </th>
    			<th> <?php echo e($row->name); ?> </th>
    			<th> <?php echo e($row->address); ?> </th>
    			<th> <?php echo e($row->pick_address); ?> </th>
    			<th> <?php echo e($row->amount); ?> </th>
                <th> <?php echo e($row->status); ?> </th>
                <th> <?php echo e($row->rider); ?> </th>
                <th> <?php echo e($row->order_id); ?> </th>
    		</tr>
    		<?php $sum += (int)$row->amount ?>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		<b>Total amount generated from <?php echo e(Session::get('from')); ?> to <?php echo e(Session::get('to')); ?> is <?php echo e(number_format($sum, 2)); ?> </b>
    	</table>
    	</div>

    </div>
</div>
<style>
    th{
        border: 1px solid #000;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/report/getsales.blade.php ENDPATH**/ ?>