<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-5 col-sm-12 panel panel-primary">
			<div class="panel-heading">Assign Despatch Rider</div>
			<div class="panel-body">

				<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>

				<?php if(Session::has('success')): ?>
				<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
				<?php endif; ?>

				<form method="post" action="<?php echo e(url('/updateorder')); ?>">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<label>Select Rider</label>
						<select name="rider" class="form-control">
							<?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option><?php echo e($row->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="form-group">
						<label>Order ID</label>
						<input type="text" name="order_id" readonly="" value="<?php echo e($row->order_id); ?>" class="form-control">
					</div>

					<div class="form-group">
						<label>Item</label>
						<input type="text" name="item" readonly="" value="<?php echo e($row->item); ?>" class="form-control">
					</div>

					<div class="form-group">
						<label>Sender</label>
						<input type="text" name="name" readonly="" value="<?php echo e($row->name); ?>" class="form-control">
					</div>

					<div class="form-group">
						<label>Pick-up Address</label>
						<input type="text" name="address" readonly="" value="<?php echo e($row->address); ?>" class="form-control">
					</div>

					<div class="form-group">
						<label>Destination</label>
						<input type="text" name="destination" readonly="" value="<?php echo e($row->pick_address); ?>" class="form-control">
					</div>
					
					<div class="form-group">
						<label>Rider to collect cash</label>
						<select class="form-control" name="collect">
						    <option value="0">NO</option>
						    <option value="1">Yes</option>
						</select>
					</div>

					
					
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<input type="submit" class="btn btn-primary" name="">

				</form>

			</div>  
		</div>



	</div>
</div>
<script type="text/javascript">
	function showMe(e) {
		var strdisplay = e.options[e.selectedIndex].value;
		var e = document.getElementById("idShowMe");
		if(strdisplay == "Wings Deposit") {
			e.style.display = "block";
		} else {
			e.style.display = "none";
		}
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/despatch/assign.blade.php ENDPATH**/ ?>