<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-5 col-sm-12 panel panel-primary">
			<div class="panel-heading">Sales By Special Customer Report</div>
			<div class="panel-body">

				<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>

				<?php if(Session::has('success')): ?>
				<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
				<?php endif; ?>
				
				<?php if(Session::has('error')): ?>
				<div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
				<?php endif; ?>

				<form method="post" action="<?php echo e(url('/getspecialcustomer')); ?>">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<label>Customer Name</label>
						<select class="form-control" name="name">
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option> <?php echo e($row->ben_name); ?> </option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>

					<div class="form-group col-sm-12 col-lg-6">
						<label>From</label>
						<input type="date" name="from" class="form-control">
					</div>

					<div class="form-group  col-sm-12 col-lg-6">
						<label>To</label>
						<input type="date" name="to" class="form-control">
					</div>

					<input type="submit" class="btn btn-primary" name="">

				</form>

			</div>  
		</div>



	</div>
</div>
<script type="text/javascript">
	function showMe(e) {
		var strdisplay = e.options[e.selectedIndex].value;
		var e = document.getElementById("idShowMe");
		if(strdisplay == "Wings Deposit") {
			e.style.display = "block";
		} else {
			e.style.display = "none";
		}
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/report/specialcustomer.blade.php ENDPATH**/ ?>