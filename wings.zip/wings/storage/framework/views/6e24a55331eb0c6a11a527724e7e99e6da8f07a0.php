<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    
				
				<td><a href="<?php echo e(url('/orderdelete/'.$row->id)); ?>" onClick="return confirm("sure to delete?")"><i class="fa fa-trash btn btn-danger"></i></a></td>
				<td><a href="<?php echo e(url('/edit/'.$row->id)); ?>">Edit</a></td>
				<td>	<?php echo e($row->type); ?> </td>
				<td>	
			    <?php if($row->assigned == 0): ?>
				    <span style="color: red;"> Unassigned </span>
				
				<?php elseif($row->assigned == 1): ?>
				    <span style="color: orange;"> Assigned </span>
				
				<?php elseif($row->assigned == 2): ?>
				    <span style="color: green;"> Delivered </span>
				<?php endif; ?>
				</td>
				<td>	<?php echo e($row->status); ?> </td>
				<td>	
				<?php if($row->status != 'paid'): ?>
			        <form method="post" action="addpayment">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="order_id" value="'.$row->order_id .'">
                        <input type="submit" class="btn btn-link" value="add payment" name="">
                    </form>
                    <?php endif; ?>
				</td>
				<td>	
			    <?php if($row->rider == ''): ?>
			        <a href="<?php echo e(url('/assign/'.$row->id)); ?>">Assign</a>
			    <?php endif; ?>
				</td> 
				<td>    <?php echo e($row->item); ?>  </td> 
				<td>    <?php echo e($row->address); ?>  </td> 
				<td>    <?php echo e($row->pick_time); ?>  </td> 
				<td>    <?php echo e($row->delivery_time); ?>  </td> 
				<td>    <?php echo e($row->order_id); ?>  </td> 
				<td>    <?php echo e($row->amount); ?>  </td> 
				<td>    <?php echo e($row->name); ?>  </td> 
				<td>    <?php echo e($row->cus_phone); ?>  </td> 
				<td>    <?php echo e($row->email); ?> </td> 
				<td>    <?php echo e($row->ben_name); ?>  </td> 
				<td>    <?php echo e($row->ben_phone); ?>  </td> 
				<td>    <?php echo e($row->pick_address); ?>  </td> 
			</tr>
       
       
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tr>
       <td colspan="10" align="center">
        <?php echo $data->links(); ?>

       </td>
      </tr><?php /**PATH /home/wingsben/wings/resources/views/pagination_data.blade.php ENDPATH**/ ?>