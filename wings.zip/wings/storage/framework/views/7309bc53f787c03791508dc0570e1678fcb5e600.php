

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

         <div class="col-lg-12">
            <a href="#" onclick="window.print()" id="printPageButton" class="btn btn-primary"><i class="fa fa-print"></i>Print</a>
        </div>

    	<table class="table table-bordered">
            <tr>
                <th colspan="8">
                    <img src="<?php echo e(asset('images/wings-logo-80x80.png')); ?>" style="width: 50px; margin-left: 100px;"><h3 style="margin-top: -40px; margin-left:150px;">WINGS BY NIINESEAS LOGISTICS</h3>
                    <span><center> Suite 17, Block B, Alausa Shopping Complex, 131 Obafemi Awolowo, Ikeja, Lagos State. </center></span>
                    <span><center><i class="fa fa-phone"></i> 0908-6532-777 ,  08097765985 <i class="fa fa-envelope"></i> info@wingsng.com </center></span>
                </th>
            </tr>
            <tr>
                <th colspan="8"><center>All Payments from <?php echo e(Session::get('from')); ?> to <?php echo e(Session::get('to')); ?></center></th>
            </tr>
    		<tr>
    			<th>Date</th>
    			<th>Order ID</th>
    			<th>Name</th>
    			<th>Amount</th>
    			<th>Payment Mode</th>
    		</tr>
            <?php $total = 0;?>
    		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<th> <?php echo e($row->created_at); ?> </th>
    			<th> <?php echo e($row->order_id); ?> </th>
                <th> <?php echo e($row->name); ?> </th>
    			<th> <?php echo e($row->amount); ?> </th>
    			<th> <?php echo e($row->mode); ?> </th>
    		</tr>
            <?php $total+=$row->amount; ?>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</table>
        Total amount generated from <?php echo e(Session::get('from')); ?> to <?php echo e(Session::get('to')); ?> is &#x20a6; <?php echo e(number_format($total, 2)); ?>

    </div>
</div>
<style type="text/css">
    @media  print {
      #printPageButton {
        display: none;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/report/getpayment.blade.php ENDPATH**/ ?>