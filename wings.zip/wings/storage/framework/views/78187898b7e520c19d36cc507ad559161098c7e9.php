<?php if(\Auth::User()->type == 1): ?>
<li><a href="<?php echo e(url('/order')); ?>">order</a></li>
<li><a href="<?php echo e(url('/rider')); ?>">Rider(s)</a></li>
<li><a href="<?php echo e(url('/expenses')); ?>">Expens(es)</a></li>
<li><a href="<?php echo e(url('/deposit')); ?>">Wings Deposit</a></li>
<li><a href="<?php echo e(url('/salesrider')); ?>">Rider Report</a></li>
<li><a href="<?php echo e(url('/expense')); ?>">Expense Report</a></li>
<li><a href="<?php echo e(url('/customer')); ?>">Customer Report</a></li>
<li><a href="<?php echo e(url('/Oassign')); ?>">Order Assigned</a></li>
<li><a href="<?php echo e(url('/unassigned')); ?>">Unassigned Order </a></li>
<li><a href="<?php echo e(url('/checkQR')); ?>">Print QR</a></li>
<li><a href="<?php echo e(url('/reassign')); ?>">Reassign Rider</a></li>

<?php if(\Auth::User()->email == 'olorunyomibalogun@gmail.com'): ?>
<li><a href="<?php echo e(url('/special')); ?>">special order</a></li>
<li><a href="<?php echo e(url('/specialcustomer')); ?>">Customer Report (Special)</a></li>
<?php endif; ?>

<?php endif; ?>

<?php if(\Auth::User()->type == 2): ?>
<li><a href="<?php echo e(url('/consign')); ?>">My Consign</a></li>
<?php endif; ?>

<?php if(\Auth::User()->type == 0): ?>
<li><a href="<?php echo e(url('/order')); ?>">order</a></li>
<li><a href="<?php echo e(url('/special')); ?>">special order</a></li>
<li><a href="<?php echo e(url('/salesrider')); ?>">Rider Report</a></li>
<li><a href="<?php echo e(url('/customer')); ?>">Customer Report</a></li>
<li><a href="<?php echo e(url('/specialcustomer')); ?>">Customer Report (Special)</a></li>
<li><a href="<?php echo e(url('/checkQR')); ?>">Print QR</a></li>
<li><a href="<?php echo e(url('/expense')); ?>">Expense Report</a></li>
<li><a href="<?php echo e(url('/expenses')); ?>">Expense(s)</a></li>
<li><a href="<?php echo e(url('/reassign')); ?>">Reassign Rider</a></li>
<li><a href="<?php echo e(url('/sales')); ?>">All Sales Report</a></li>
<li><a href="<?php echo e(url('/pay')); ?>">Payment Report</a></li>
<li><a href="<?php echo e(url('/worker')); ?>">Front Line</a></li>
<li><a href="<?php echo e(url('/rider')); ?>">Rider(s)</a></li>
<li><a href="<?php echo e(url('/deposit')); ?>">Wings Deposit</a></li>
<li><a href="<?php echo e(url('/consign')); ?>">My Consign</a></li>
<li><a href="<?php echo e(url('/Oassign')); ?>">Order Assigned</a></li>
<li><a href="<?php echo e(url('/unassigned')); ?>">Unassigned Order </a></li>
<?php endif; ?><?php /**PATH /Library/WebServer/Documents/wings/resources/views/layouts/menu.blade.php ENDPATH**/ ?>