<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<?php if(Session::has('success')): ?>
    	<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    	<?php endif; ?>

    	<?php if(Session::has('error')): ?>
    	<div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
    	<?php endif; ?>

    	<table class="table table-bordered">
    		<tr>
    			<th colspan="4"><center><a href="<?php echo e(url('/addrider')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Add new Rider</a></center></th>
    		</tr>
    		<tr>
    			<th>Rider Name</th>
    			<th>Rider id</th>
    			<th>Rider Address</th>
    			<th>Rider Phone</th>
    			<th></th>
    			<th></th>
    		</tr>
    		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<th><?php echo e($row->name); ?></th>
    			<th><?php echo e($row->rider_id); ?></th>
    			<th><?php echo e($row->address); ?></th>
    			<th><?php echo e($row->phone); ?></th>
    			<td><a href="<?php echo e(url('/rideredit/'.$row->id)); ?>">Edit</a></td>
    			<td><a href="<?php echo e(url('/riderdelete/'.$row->id)); ?>"><i class="fa fa-trash btn btn-danger"></i></a></td>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</table>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/rider/allriders.blade.php ENDPATH**/ ?>