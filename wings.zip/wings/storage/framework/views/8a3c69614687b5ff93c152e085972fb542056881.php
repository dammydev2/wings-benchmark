<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<table class="table table-bordered">
    		<tr>
    			<th>Date</th>
    			<th>Name</th>
    			<th>Expenses for</th>
    			<th>Details</th>
    			<th>telephone</th>
    		</tr>
    		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<th> <?php echo e($row->created_at); ?> </th>
    			<th> <?php echo e($row->name); ?> </th>
    			<th> <?php echo e($row->expenses); ?> </th>
    			<th> <?php echo e($row->details); ?> </th>
    			<th> <?php echo e($row->telephone); ?> </th>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</table>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/report/getexpense.blade.php ENDPATH**/ ?>