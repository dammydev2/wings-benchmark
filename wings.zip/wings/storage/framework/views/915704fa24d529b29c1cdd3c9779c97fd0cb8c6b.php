

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-5 col-sm-12 panel panel-primary">
			<div class="panel-heading">Add New</div>
			<div class="panel-body">

				<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>

				<?php if(Session::has('success')): ?>
				<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
				<?php endif; ?>

				<form method="post" action="<?php echo e(url('/addnewings')); ?>">
					<?php echo csrf_field(); ?>

					<div class="form-group">
						<label>Customer Name</label>
						<input type="text" name="name" class="form-control">
					</div>

					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email" class="form-control">
					</div>

					<div class="form-group">
						<label>Phone</label>
						<input type="text" name="phone" class="form-control">
					</div>

					<div class="form-group">
						<label>Amount</label>
						<input type="text" name="amount" class="form-control">
					</div>

					<input type="submit" class="btn btn-primary" name="">

				</form>

			</div>  
		</div>



	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/despatch/addnewdeposit.blade.php ENDPATH**/ ?>