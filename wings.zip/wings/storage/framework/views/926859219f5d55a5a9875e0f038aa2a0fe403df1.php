<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<?php if(Session::has('success')): ?>
    	<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    	<?php endif; ?>

    	<?php if(Session::has('error')): ?>
    	<div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
    	<?php endif; ?>

    	<table class="table" style="display: block; overflow-x: scroll; overflow-y: scroll;">
    		<tr>
    			<th colspan="4"><center><a href="<?php echo e(url('/addnewdeposit')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Add new</a></center></th>
    		</tr>
    		<tr>
    			<th>Name</th>
                <th>Wings ID</th>
                <th>email</th>
    			<th>Phone</th>
                <th>Amount</th>
    		</tr>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->wings_id); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->phone); ?></td>
                <td><?php echo e(number_format($row->amount, 2)); ?></td>
                <td><a href="<?php echo e(url('/addeposit/'.$row->id)); ?>">Add Payment</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
    		
    	</table>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/despatch/deposit.blade.php ENDPATH**/ ?>