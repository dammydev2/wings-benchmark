<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

       <div class="col-lg-12">
        <a href="#" onclick="window.print()" id="printPageButton" class="btn btn-primary"><i class="fa fa-print"></i>Print</a>
    </div>

    <div class="col-lg-10 col-sm-12">
    	<table class="table">
            <tr>
                <th colspan="8">
                    <img src="<?php echo e(asset('images/wings-logo-80x80.png')); ?>" style="width: 50px; margin-left: 100px;"><h3 style="margin-top: -40px; margin-left:150px;">WINGS BY NINESEAS LOGISTICS</h3>
                    <span><center> Suite 17, Block B, Alausa Shopping Complex, 131 Obafemi Awolowo, Ikeja, Lagos State. </center></span>
                    <span><center><i class="fa fa-phone"></i> 0908-6532-777 ,  08097765985 <i class="fa fa-envelope"></i> info@wingsng.com </center></span>
                </th>
            </tr>
            <tr>
                <th colspan="8"><center><?php echo e(Session::get('customer')); ?> delivery data from <?php echo e(Session::get('from')); ?> to <?php echo e(Session::get('to')); ?></center></th>
            </tr>
            <tr>
             <th>Date</th>
             <th>Name of client</th>
             <th>Pick up Point</th>
             <th>Delivery Point</th>
             <th>Payment Status</th>
             <th>Desatch by</th>
             <th>Order ID</th>
             <th>Amount</th>
         </tr>
         <?php $sum=0; ?>
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
             <th> <?php echo e($row->created_at); ?> </th>
             <th> <?php echo e($row->name); ?> </th>
             <th> <?php echo e($row->address); ?> </th>
             <th> <?php echo e($row->pick_address); ?> </th>
             <th> <?php echo e($row->status); ?> </th>
             <th> <?php echo e($row->rider); ?> </th>
             <th> <?php echo e($row->order_id); ?> </th>
             <th> <?php echo e($row->amount); ?> </th>
             <?php $sum += $row->amount ?>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <tr>
          <th colspan="7" class="text-right">Cost of Delivery</th>
          <th> <?php echo e(number_format($sum, 2)); ?> </th>
      </tr>
      <tr style="color: red;">
          <th colspan="7" class="text-right">Paid for</th>
          <th>
              <?php $sum2=0; ?> 
              <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $sum2 += $row2->amount ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php echo e(number_format($sum2, 2)); ?>

          </th>
      </tr>
  </table>
</div>

<form class="col-sm-12 col-lg-4" method="post" action="<?php echo e(url('/sendmail')); ?>">
    <?php echo csrf_field(); ?>
    <label>Email Address</label>
    <input type="email" name="email" class="form-control" value="<?php echo e($row->email); ?>">
    <input type="hidden" name="name" class="form-control" value="<?php echo e($row->name); ?>">
    <input type="submit" name="" class="btn btn-primary" value="send to customer">
</form>

</div>
</div>
<style type="text/css">
    @media  print {
      #printPageButton {
        display: none;
    }
}

th{
    border: 1px solid #000;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/report/getcustomer.blade.php ENDPATH**/ ?>