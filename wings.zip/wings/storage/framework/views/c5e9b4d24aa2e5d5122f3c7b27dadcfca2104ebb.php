<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

<div class="col-sm-12 col-sm-10">
    	<table class="table" border="1" >
    		<tr>
    			<th>Date</th>
    			<th>Name</th>
    			<th>Expenses for</th>
    			<th>Details</th>
    			<th>amount</th>
    			<th></th>
    		</tr>
    		<?php $count=0; ?>
    		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<th> <?php echo e($row->created_at); ?> </th>
    			<th> <?php echo e($row->name); ?> </th>
    			<th> <?php echo e($row->expenses); ?> </th>
    			<th> <?php echo e($row->details); ?> </th>
    			<th> <?php echo e($row->amount); ?> </th>
    			<th><a href="<?php echo e(url('expensedelete/'.$row->id)); ?>"><i class="fa fa-trash btn btn-danger"></i></a></th>
    			<?php $count +=$row->amount; ?>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    		    <th colspan="4" class="text-right">Total</th>
    		    <th><?php echo e(number_format($count,2)); ?></th>
    		</tr>
    	</table>
    	</div>

    </div>
</div>
<style>
    th{
        border: 1px solid #000;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/report/getexpense.blade.php ENDPATH**/ ?>