<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    <div class=" col-sm-12 col-lg-10">
    	<table class="table" border="1">
    		<tr>
    			<th>Date</th>
    			<th>Name of client</th>
    			<th>Pick up Point</th>
    			<th>Delivery Point</th>
    			<th>Amount</th>
                <!--<th>Status</th>-->
                <th>Assigned to</th>
                <th>Order ID</th>
    		</tr>
    		<?php $count =0; ?>
    		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<?php
    		    $dt = new DateTime($row->created_at);
    		    $count += (int)$row->amount;

$date = $dt->format('d/m/Y');
    		?>
    		<tr>
    			<td> <?php echo e($date); ?> </td>
    			<td> <?php echo e($row->name); ?> </td>
    			<td> <?php echo e($row->address); ?> </td>
    			<td> <?php echo e($row->destination); ?> </td>
    			<td> <?php echo e($row->amount); ?> </td>
                <td> <?php echo e($row->rider); ?> </td>
                <td> <?php echo e($row->order_id); ?> </td>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    		    <th colspan="4" class="text-right">Total</th>
    		    <th><?php echo e(number_format($count, 2)); ?></th>
    		    <th colspan="2"></th>
    		</tr>
    	</table>
    	</div>

    </div>
</div>
<style>
    td{
        border: 1px solid #000;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/report/getassign.blade.php ENDPATH**/ ?>