<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<table class="table table-bordered">
    		<tr>
    			<th>Date</th>
    			<th>Name of client</th>
    			<th>Pick up Point</th>
    			<th>Delivery Point</th>
    			<th>Amount</th>
                <th>Status</th>
                <th>Desatch by</th>
                <th>Order ID</th>
    		</tr>
    		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<tr>
    			<th> <?php echo e($row->created_at); ?> </th>
    			<th> <?php echo e($row->name); ?> </th>
    			<th>  </th>
    			<th> <?php echo e($row->pick_address); ?> </th>
    			<th> <?php echo e($row->amount); ?> </th>
                <th> <?php echo e($row->status); ?> </th>
                <th> <?php echo e($row->rider); ?> </th>
                <th> <?php echo e($row->order_id); ?> </th>
    		</tr>
    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	</table>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/report/getrider.blade.php ENDPATH**/ ?>