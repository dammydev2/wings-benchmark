

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-5 col-sm-12 panel panel-primary">
			<div class="panel-heading">Edit Rider</div>
			<div class="panel-body">

				<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>

				<form method="post" action="<?php echo e(url('/updaterider')); ?>">
					<?php echo csrf_field(); ?>

					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="form-group">
						<label>Rider's Name</label>
						<input type="text" name="name" value="<?php echo e($row->name); ?>" class="form-control">
					</div>

					<div class="form-group">
						<label>Rider's Address</label>
						<input type="text" name="address" value="<?php echo e($row->address); ?>" class="form-control">
					</div>

					<div class="form-group">
						<label>Rider's Phone</label>
						<input type="text" name="phone" value="<?php echo e($row->phone); ?>" class="form-control">
					</div>

					<input type="hidden" name="id" value="<?php echo e($row->id); ?>">
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<input type="submit" value="update" class="btn btn-primary" name="">

				</form>

			</div>  
		</div>



	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/rider/rideredit.blade.php ENDPATH**/ ?>