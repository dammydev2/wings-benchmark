<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

        <div class="col-sm-12 col-lg-10">
        	<table class="table table-bordered">
        		<tr>
        			<th>Date</th>
        			<th>Name of client</th>
        			<th>Pick up Point</th>
        			<th>Delivery Point</th>
        			<th>Amount</th>
                    <!--<th>Status</th>-->
                    <th>Desatch by</th>
                    <th>Order ID</th>
        		</tr>
        		<?php $count=0; ?>
        		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<?php $count += $row->amount ?>
        		<tr>
        			<th> <?php echo e($row->created_at); ?> </th>
        			<th> <?php echo e($row->name); ?> </th>
        			<th> <?php echo e($row->address); ?> </th>
        			<th> <?php echo e($row->destination); ?> </th>
        			<th> <?php echo e(number_format($row->amount, 2)); ?> </th>
                    <th> <?php echo e($row->rider); ?> </th>
                    <th> <?php echo e($row->order_id); ?> </th>
        		</tr>
        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        		<tr>
        		    <td colspan='4' class="text-right">Total</td>
        		    <td class="text-right"><?php echo e(number_format($count, 2)); ?></td>
        		</tr>
        	</table>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/report/getrider.blade.php ENDPATH**/ ?>