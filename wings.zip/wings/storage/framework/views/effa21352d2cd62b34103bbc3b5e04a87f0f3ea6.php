<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

    	<?php if(Session::has('success')): ?>
    	<div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
    	<?php endif; ?>

    	<?php if(Session::has('error')): ?>
    	<div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
    	<?php endif; ?>

    	<table class="table" style="display: block; overflow-x: scroll; overflow-y: scroll; width: 80%">
    		<tr>
    			<th colspan="4"><center><a href="<?php echo e(url('/addorder')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Add new order</a></center></th>
    		</tr>
    		<tr>
    			<th>Type</th>
                <th>Item</th>
                <th>Pick-up Address</th>
                <th>Order ID</th>
    			<th>Amount</th>
    			<th>Customer name</th>
                <th>Customer phone</th>
                <th>Customer email</th>
                <th>Beneficiary Name</th>
                <th>Beneficiary phone</th>
                <th>Beneficiary address</th>
    			<th>Delivery status</th>
                <th>Payment status</th>
    			<th></th>
    		</tr>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->type); ?></td>
                <td><?php echo e($row->item); ?></td>
                <td><?php echo e($row->address); ?></td>
                <td><?php echo e($row->order_id); ?></td>
                <td><?php echo e($row->amount); ?></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->cus_phone); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td><?php echo e($row->ben_name); ?></td>
                <td><?php echo e($row->ben_phone); ?></td>
                <td><?php echo e($row->pick_address); ?></td>
                <td>
                    <?php if($row->assigned == 0): ?>

                   <span style="color: red;"> Unassigned </span>

                    <?php elseif($row->assigned == 1): ?>

                   <span style="color: orange;"> Assigned </span>

                    <?php elseif($row->assigned == 2): ?>

                   <span style="color: green;"> Delivered </span>

                    <?php endif; ?>
                </td>
                <td><?php echo e($row->status); ?></td>
                <td>
                    <?php if($row->status != 'paid'): ?>
                    <form method="post" action="<?php echo e(url('/addpayment')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="order_id" value="<?php echo e($row->order_id); ?>">
                        <input type="submit" class="btn btn-link" value="add payment" name="">
                    </form>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($row->rider == ''): ?>
                    <a href="<?php echo e(url('/assign/'.$row->id)); ?>">Assign</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($data->links()); ?>

    		
    	</table>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/despatch/order.blade.php ENDPATH**/ ?>