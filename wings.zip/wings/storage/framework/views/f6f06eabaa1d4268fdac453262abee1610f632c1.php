

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-lg-12">
      <a href="#" onclick="window.print()" id="printPageButton" class="btn btn-primary"><i class="fa fa-print"></i>Print</a>
    </div>

    <div class="col-lg-2"></div>

    <div class="col-lg-8">
        
        
            
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!--::::::::THE QR CODE IS HERE:::::::-->
            <span style=""> <?php echo QrCode::size(150)->generate('Item: '. $row->item. ' | Sender Name: '. $row->name . ' | Pick-up Address: '. $row->address . ' | Destination: '. $row->pick_address . ' | Reciever Name: '. $row->ben_name . ' | Reciever Phone: '. $row->ben_phone . ' | Wings Delivery ' );; ?><br> <span style="margin-top: -150px;"><?php echo e($row->order_id); ?></span> </span><hr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



      </div>
      
    </div>
  </div>

  <style type="text/css">
    @media  print {
      #printPageButton {
        display: none;
      }
    }
  </style>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wingsben/wings/resources/views/report/multipleQR.blade.php ENDPATH**/ ?>