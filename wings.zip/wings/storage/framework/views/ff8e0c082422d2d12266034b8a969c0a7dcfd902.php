<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">

<div class="col-sm-12 col-lg-8">
    	<table class="table table-bordered">
            <tr>
                <th colspan="2"><center><a href="<?php echo e(url('/addworker')); ?>" class="btn btn-primary"><i class="fa fa-user-plus"></i>Add New Worker</a></center></th>
            </tr>
    		<tr>
    			<th>Name</th>
    			<th>Email</th>
    		</tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th> <?php echo e($row->name); ?> </th>
                <th> <?php echo e($row->email); ?> </th>
                <th>
                    <?php if($row->type == 1): ?>
                    Front-Desk / Secretary
                    <?php elseif($row->type == 2): ?>
                    Rider
                    <?php endif; ?>
                </th>
                <th>
                    <a href="<?php echo e(url('/workerdelete/'.$row->id)); ?>" onclick="return confirm('Are you sure?')"><i class="fa fa-trash btn btn-danger"></i></a>
                </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		
    	</table>
    </div>

    </div>
</div>
<style type="text/css">
    @media  print {
      #printPageButton {
        display: none;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wings\resources\views/report/worker.blade.php ENDPATH**/ ?>